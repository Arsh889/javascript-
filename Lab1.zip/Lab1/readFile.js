// Import the 'fs' module (file system) for file operations
const fs = require('fs');

// Specify the path to your text file
const filePath = 'content.txt';

// Use asynchronous readFile function
fs.readFile(filePath, 'utf8', (err, data) => {
  if (err) {
    console.error(`Error reading the file: ${err.message}`);
    return;
  }

  // Output the content to the terminal
  console.log('File Contents:\n', data);
});
